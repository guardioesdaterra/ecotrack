'use client'
export const dynamic = 'force-dynamic'

export default function ErrorPage() {
  return (
    <div>
      <h1>500 - Internal Server Error</h1>
      <p>Sorry, something went wrong.</p>
    </div>
  )
}